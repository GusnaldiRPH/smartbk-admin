import { createClient } from "@supabase/supabase-js";

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL as string;
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY as string;

if (!supabaseUrl || !supabaseAnonKey) {
  // eslint-disable-next-line no-console
  console.warn(
    "Supabase env vars belum diisi. Copy .env.local.example jadi .env.local dan isi URL + anon key project kamu."
  );
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
